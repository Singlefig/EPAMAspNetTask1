﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var articles = new List<Article> {
                new Article
                {
                    Title="My Blog",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
                new Article
                {
                    Title="My Blog2",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
                new Article
                {
                    Title="My Blog3",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
            };
            return View(articles);
        }

        public ActionResult GuestPage()
        {
            var comments = new List<Comment> {
                new Comment
                {
                    Name="Comment",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
                new Comment
                {
                    Name="Comment2",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
                new Comment
                {
                    Name="Comment3",
                    Date=DateTime.Now,
                    Text="skjbcdkjdckjsdchjkschdkjsdhcjksdhc"
                },
            };
            return View(comments);
        }

        [HttpGet]
        public ActionResult Quiz()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Quiz(QuizModel quizModel)
        {
            var quizCollection = new List<QuizModel>();

            if(Session["quizCollection"] != null)
            {
                quizCollection.Add((QuizModel)Session["quizCollection"]);
            }

            quizCollection.Add(quizModel);

            Session["quizCollection"] = quizCollection;
            return RedirectToAction("QuizResult");
        }

        public ActionResult QuizResult(QuizModel quizModel)
        {
            var quizCollection = new List<QuizModel>();
            if (Session["quizCollection"] != null)
            {
                quizCollection = (List<QuizModel>)Session["quizCollection"];
            }

            return View(quizCollection);
        }

        public ActionResult QuizForUser()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult GuestPage(QuizModel model)
        //{
        //    return RedirectToAction("ShowQuizResult");
        //}
        //[HttpPost]
        //public ActionResult QuizResult(QuizModel quizModel)
        //{
        //    //if(ModelState.IsValid)
        //    //{

        //    //}
        //    return View();
        //}
    }
}