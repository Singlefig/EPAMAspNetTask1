﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class QuizModel
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }
        [Display(Name = "Email address")]
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        public bool isCheckedPC { get; set; }
        public bool isCheckedPS4 { get; set; }
        public bool isCheckedXbox { get; set; }
        public bool isCheckedNintendo { get; set; }
        public bool radioMale { get; set; }
        public bool radioFemale { get; set; }
        public bool radioOther { get; set; }
    }
}